<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="../view/CSS/home.css">
	<style type="text/css">
		.header a.active {
		  background-color: dodgerblue;
		  color: white;
		}
	</style>
</head>
<body>
	<?php include('../Include/Header.html'); ?>
	<div class="c1">
		<br>
		<b id="p1">We are committed to provide affordable services, without any compromise on the quality of service – so that you are able to remain happy.</b>
		<h1>Our services</h1>
		<button class="button" type="button">Order food</button>
		<br><br>
		<button class="button" type="button">See menu</button>
		<br><br>
		<button class="button" type="button">Register</button>
		<br>
		<br>
	</div><hr>
	

	<?php include('../Include/Footer.html'); ?>
</body>
</html>