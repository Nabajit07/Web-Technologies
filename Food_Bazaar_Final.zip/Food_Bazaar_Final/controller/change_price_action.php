<?php 
	
	if ($_SERVER["REQUEST_METHOD"] === "POST") {

		$decode = json_decode($_POST["obj"], false);

		$username = $decode->username;
		$newTime = $decode->newTime;


		if (empty($username) or empty($newTime)) {
			
			if(empty($username)){
				echo '<b style="color: red;>Please Select a item!</b>';
			}
			else{
				echo '<b style="color: red;>Please enter new price!</b>';
			}
		}
		else {
			if(is_numeric($newTime)){
				$servername = "localhost";
				$us = "root";
				$pass = "";
				$dbname = "food";

				$connection = new mysqli($servername, $us, $pass, $dbname);

				if ($connection->connect_error) {
					die("Connection failed: " . $connection->connect_error);
				}
				else{

					$sql = "select * from food_info where foodName = '".$username."'";

					$data = $connection->query($sql);

					if ($data->num_rows > 0) {

						$row = $data->fetch_assoc();

						$sql = "UPDATE food_info set price = ? WHERE foodName = '".$username."'";

						$stmt = $connection->prepare($sql);

						$stmt->bind_param("s", $newTime);

						$res = $stmt->execute();

						if ($res) {
							echo "<b>Successfully changed food price!</b>";
						}
						else {
							echo "<b>Error while changing!</b>";
						}
										
					}
					else{
										
						echo '<b style="color: red;">This user may be deleted!</b>';
					}
					$connection->close();
				}
			}
			else{
				echo '<b style="color: red;">Price must be a number!</b>';
			}
		}
	}


?>