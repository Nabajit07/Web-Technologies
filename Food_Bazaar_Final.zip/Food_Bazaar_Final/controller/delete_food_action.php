<?php 
	
	if ($_SERVER["REQUEST_METHOD"] === "POST") {

		$decode = json_decode($_POST["obj"], false);

		$username = $decode->username;


		if (empty($username)) {
			echo '<b style="color: red;">Please Select a user!</b>';
		}
		else {
			$servername = "localhost";
			$us = "root";
			$pass = "";
			$dbname = "food";

			$connection = new mysqli($servername, $us, $pass, $dbname);

			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}
			else{

				$sql = "select * from food_info where foodName = '".$username."'";

				$data = $connection->query($sql);

				if ($data->num_rows > 0) {

					$row = $data->fetch_assoc();
					$sql = "delete from food_info WHERE foodName = ?";
					$stmt = $connection->prepare($sql);
					$stmt->bind_param("s", $username);
					$res = $stmt->execute();

					if ($res) {
						echo "<b>Successfully deleted food item!</b>";

					}
					else {
						echo '<b style="color: red;">Error while deleting!</b>$username';
					}
									
				}
				else{
									
					echo '<b style="color: red;">This food may be deleted!</b>';
				}
				$connection->close();
			}
		}
	}


?>