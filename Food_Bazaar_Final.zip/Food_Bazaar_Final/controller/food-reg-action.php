<?php 
	
	if ($_SERVER["REQUEST_METHOD"] === "POST") {

		$decode = json_decode($_POST["obj"], false);

		$username = $decode->username;
		$password = $decode->password;


		if (empty($username) or empty($password)) {
			echo "<b>Please fill up the form properly</b>";
		}
		else {
			if(!is_numeric($password)) {
				    echo '<b style="color: red;"><br>Price must be a number.</br></b>';
			}
			else{
				$servername = "localhost";
				$us = "root";
				$pass = "";
				$dbname = "food";

				$connection = new mysqli($servername, $us, $pass, $dbname);

				if ($connection->connect_error) {
					die("Connection failed: " . $connection->connect_error);
				}
				else{
			
						$sql = "INSERT INTO food_info (foodName, price) VALUES (?, ?)";
						$stmt = $connection->prepare($sql);
						$stmt->bind_param("ss", $username, $password,);
						$res = $stmt->execute();

						if ($res) {
							echo "<b>Successfully added in menu</b>";
						}
						else {
							echo "<b>Error while adding!</b>";
						}
					$connection->close();
				}
			}
			
		}
	}
?>