<?php 
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "food";



	$connection = new mysqli($servername, $user, $pass, $dbname);

	if ($connection->connect_error) {
		die("Connection failed: " . $connection->connect_error);
	}
	else{
		echo '<table id = "tableSelect" class="styled-table">
			<thead>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Select</th>
			</tr>
			</thead> <tbody>';
		$sql = "select * from food_info";
		$data = $connection->query($sql);
		if ($data->num_rows > 0) {	
			while ($row = $data->fetch_assoc()) {
				$firstname = $row["foodName"];
				$lastname = $row["price"];
				echo '<tr> <td>';
				echo $firstname;
				echo " ";
				/*echo $lastname*/;
				echo '</td> <td>';
				echo $lastname;
				echo " ৳";
				/*echo $lastname*/;
				echo '</td> <td>';
				echo '<input type="radio" name="remember" value = "';
				echo $firstname;
				echo '"><label></label></td></tr>';
			}
			echo '</tbody></table>';
		}
		else{
			echo "<b>No data found!</b>";
		}
	}
?>