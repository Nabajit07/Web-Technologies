<?php 
	header("Location: controller/Home.php")
?>