function sendData(formData){
	if(formData.userName.value === ""||formData.password.value === "" ){

		if(formData.userName.value === ""){
			document.getElementById("errorMsgUser").innerHTML = "Please fill food name!";
		}
		else{
			document.getElementById("errorMsgUser").innerHTML = "";
		}

		if(formData.password.value === ""){
			document.getElementById("errorMsgPass").innerHTML = "Please fill price details!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
			if(!value(formData.password.value)){
				document.getElementById("errorMsgPass").innerHTML = "";
			}
			else{
				document.getElementById("errorMsgPass").innerHTML = "Price must be a value";
			}
		}
	}
	else{
		document.getElementById("errorMsgUser").innerHTML = "";
		document.getElementById("errorMsgPass").innerHTML = "";



		const xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState === 4 && this.status === 200) {
					document.getElementById("msg").innerHTML = this.responseText;
				}
			}
			xhttp.open(formData.method, formData.action);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			const myData = {
				"username" : formData.userName.value,
				"password" : formData.password.value

			}
			xhttp.send("obj="+JSON.stringify(myData));
	}

}