<?php 

	session_start();

	if(count($_SESSION) == 0){

		header("Location: ../view/loginAdmin.php");
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Add Food</title>
	<link rel="stylesheet" type="text/css" href="../view/CSS/loginAdmin.css">
	<style>
		#msg{
			color: green;
		}
	</style>
	<link rel="stylesheet" type="text/css" href="../view/CSS/table.css">
	<style>
		#msg1{
			color: red;
			font-size: 18px;
		}

		#msgOk{
			color: green;
			font-size: 18px;
		}
	</style>
</head>
<script src="../view/JS/add_food.js"></script>
<script src="../view/JS/food_uniqueName.js"></script>

<body>
	<?php include('../Include/adminHeader.html'); ?>
	<p>Welcome to <b>add food</b> page. You can add food and <b>price</b> information. You also can change information later. </p>
	<fieldset><legend> <b>Current list</b> </legend>
	<div id="refresh-table">

				<?php 
					include '../controller/food_table_create.php';
				?>

			</div></fieldset>
	<fieldset>
		<legend> <b>Add food</b> </legend>
		<br>
			<form action="../controller/food-reg-action.php" name = "login" onsubmit="sendData(this); return false;" method="POST">
					<br>
					<!-- <label>Food Name:</label>
					<input type="text" name="firstname" placeholder="Enter firstname">

					<p id = "errorMsgName" class="e1"></p>

					<label>Last Name:</label> 
					<input type="text" name="lastname" placeholder="Enter lastname">

					<p id = "errorMsgLast" class="e1"></p> -->

					<label>Food Name: </label>
					<input type="text" placeholder="Enter a unique foodname" name="userName" onkeyup="showHint(this.value)">

					<p id = "errorMsgUser" class="e1"></p>

					<label>Food Price: </label>
					<input type="text" placeholder="Enter price" name="password">
					
					<p id = "errorMsgPass" class="e1"></p>

					<input id = "sub2" type="reset" name="reset" value="Reset" >
					<input id = "sub1" type="submit" name="Register" value="Add Food">
			</form>
			<p id="msg"></p>
		</fieldset>
		<br>
		<script>
				$('#tableSelect tr').click(function() {
				    $(this).find('th input:radio').prop('checked', true);
				})
								
				function myFun(){
					$('#refresh-table').load(location.href + " #refresh-table");
				}
			</script>

	<?php include('../Include/Footer.html'); ?>

</body>
</html>