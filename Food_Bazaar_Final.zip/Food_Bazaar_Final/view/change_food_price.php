<?php 

	session_start();

	if(count($_SESSION) == 0){

		header("Location: ../view/loginAdmin.php");
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Change food price</title>
	<link rel="stylesheet" type="text/css" href="../view/CSS/table.css">
	<style>
		#msg1{
			color: red;
			font-size: 18px;
		}

		#msgOk{
			color: green;
			font-size: 18px;
		}
	</style>
</head>
<script src="../view/JS/change_price.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../view/CSS/loginAdmin.css">
<body>
	<?php include('../Include/adminHeader.html'); ?>
	<p>Welcome to <b>change food price</b> page. You can change food price from food items. </p>

		<legend> <b>Change work schedule</b> </legend>
			<form action="../controller/change_price_action.php" name = "login" onsubmit="sendData(this); return false;" method="POST">

			<div id="refresh-table">

				<?php 
					include '../controller/food_table_create.php';
				?>

			</div>

					 <label>Enter new price:</label>
						<input type="number" step=any name="price">
						<br><br>

					<p id="msg1" ></p>
					<!-- <p id="msg2" ></p> -->

					<!-- <input id = "sub2" type="reset" name="reset" value="Refresh" > -->
					<input id = "sub1" onclick="myFun();" type="submit" name="giveDiscount" value="Change price">

			</form>

			<p id="msgOk"></p>
			<script>
				$('#tableSelect tr').click(function() {
				    $(this).find('th input:radio').prop('checked', true);
				})
								
				function myFun(){
					$('#refresh-table').load(location.href + " #refresh-table");
				}
			</script>

<br>
	

	<?php include('../Include/Footer.html'); ?>

</body>
</html>