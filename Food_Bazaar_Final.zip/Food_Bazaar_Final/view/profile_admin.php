<?php 

	session_start();

	if(count($_SESSION) == 0){

		header("Location: ../view/loginAdmin.php");
	}

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Admin profile</title>
	<link rel="stylesheet" type="text/css" href="../view/CSS/profile_admin.css">
	<style>
		.header a.home {
		  background-color: dodgerblue;
		  color: white;
		}
	</style>
</head>
<body>
	<?php include('../Include/adminHeader.html'); ?>

	<div class="c1">
		<br>
		 <b id="p1" style="font-size: 20px;">Wellcome, <?php echo $_SESSION['userName']; ?>. You have admin privilege. You can manipulate the following data/functionality.</b><br><br><br>
		 
		
			<a href="../view/reg_admin.php" class="button">Create Admin account</a>
			<br><br>
			<a href="../view/reg_staff.php" class="button">Create Employee account</a>
			<br><br>
			<a href="../view/delete_staff.php" class="button">Delete Employee account</a>
			<br><br>
			<a href="../view/addFood.php" class="button">Add food in menu</a>
			<br>
			<br>
			<a href="../view/delete_food.php" class="button">Delete food item</a>
			<br><br>
			<a href="../view/change_food_price.php" class="button">Update food price</a>
			<br>
			<br>
		
	</div>
	<?php include('../Include/Footer.html'); ?>

</body>
</html>